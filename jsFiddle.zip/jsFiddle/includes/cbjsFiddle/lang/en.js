CKEDITOR.plugins.setLang( 'cbjsFiddle', 'en', {
	title: 'jsFiddle',
	menu: 'Embed jsFiddle',
	toolbar: 'Insert jsFiddle',
	edit: 'Edit jsFiddle'
});
